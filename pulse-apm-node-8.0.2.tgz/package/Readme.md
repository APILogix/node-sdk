    setup(context) {
        console.log('Pulse project:', context.metadata.projectId)
    },
    processEvent(event) {
        return { ...event, deploymentRing: 'canary' } as typeof event
    },
    processBreadcrumb(breadcrumb) {
        return breadcrumb.category === 'noise' ? null : breadcrumb
    },
    beforeSend(event) {
        return event
    },
    afterSend(events) {
        console.log('sent', events.length)
    },
    teardown() {}
}

await createSDK({
    apiKey: process.env.PULSE_API_KEY!,
    plugins: [plugin],
    eventProcessors: [(event) => event],
    beforeBreadcrumb: (breadcrumb) => breadcrumb,
    beforeSend: (event) => event
})
```

Plugin names must be unique. Plugins may also implement `beforeFlush` and `onTransportError`; invocation depends on the active transport path. Do not put secrets in extension-generated fields. Authoritative SDK/application metadata is restored after these hooks.

## 9. Sampling, remote configuration, entitlements, and killswitches

Remote config is schema-versioned and controls:

- feature subsystem construction;
- per-family deterministic sampling for traces, requests, errors, profiles, replays, and metrics;
- longest-prefix route sampling overrides;
- instrumentation selection;
- privacy capture, scrubbing, and PII masking;
- limits and tenant governance;
- route URLs, batching, queue overflow, retries, connection concurrency, and timeouts;
- event-signalled atomic configuration replacement;
- entitlements and emergency killswitches.

Sampling uses a deterministic FNV-1a decision key. Route overrides apply by longest matching string prefix; a rate of zero drops that family for the route. Traces are sampled at root creation with parent-based inheritance. Non-trace helpers use their documented family-specific sampling path.

Entitlement denial is silent:

- `customSpans`: custom span APIs return non-recording spans.
- `customMetrics`: metric helpers drop calls.
- `profiling`: profile APIs return `false`/no-op.
- `logging`, `sessionReplay`, `crons`: corresponding capture helpers no-op.

Core error/message capture, scope, context, breadcrumbs, flush, and shutdown are not billing-entitlement gated, though feature flags, killswitches, sampling, or runtime pressure may still affect telemetry.

Killswitches are `disableSDK`, `disableTracing`, `disableMetrics`, `disableTransport`, `disableProfiling`, `disableErrors`, and `disableLogs`. They apply to new work and trigger registered subsystem teardown/startup. Do not rely on a disabled transport as a durable local queue: router rejection can drop events.

## 10. Flush and shutdown

```ts
import { flush, shutdown, crashFlush } from '@pulse-apm/node'

await flush() // drain pipeline, transport, and persistence; SDK stays active

const result = await shutdown(10_000)
if (!result.completed) {
    console.warn({
        timedOut: result.timedOut,
        remainingEvents: result.remainingEvents,
        stepErrors: result.stepErrors
    })
}

await crashFlush(2_000) // crash path only
```

- `flush()` drains deferred pipeline tasks, flushes all transport routes, then flushes persistence. It does not tear down the runtime.
- `shutdown(timeoutMs?)` is single-flight, rejects new captures, tears down subsystems, flushes tracing/pipeline/transport, persists residuals, and resets globals. It never throws and returns a `ShutdownResult`. If the public deadline wins, exclusive cleanup continues in the background.
- `crashFlush(timeoutMs = 2000)` races a pipeline/transport drain against a hard timeout, swallows errors, and does not run plugin/subsystem teardown or persistence flush.

SIGTERM and SIGINT handlers are registered after successful initialization and initiate graceful shutdown, but application process-exit policy remains the application's responsibility. SIGKILL cannot be handled.

## 11. Privacy and security

Backend privacy policy should keep header, body, response, query, and cookie capture disabled unless explicitly required. Scrubbing rules should redact authorization, cookie, API-key, password, OAuth token/code, national identifier, and payment fields; optional PII detection masks email, phone, and IP patterns. Payloads are scrubbed again at the transport boundary.

Operational guidance:

1. Keep body, response, query, cookie, and header capture off remotely unless required.
2. Add organization-specific secrets through remote `privacy.scrubbing.headers` and `privacy.scrubbing.fields`.
3. Never place credentials in span names, metric names/tags, route names, or monitor slugs.
4. Configure `trustedProxies` narrowly; never trust forwarded IP headers from arbitrary clients.
5. Keep `sourceMaps.allowRemote` false unless remote retrieval is required and reviewed.
6. Protect the host's cache directory: fallback persistence contains failed telemetry and file creation currently follows OS permissions/umask rather than declaring a private mode in the storage API.
7. Restrict API keys and do not log them. Transport uses `redirect: 'manual'` so bearer credentials are not followed to redirected origins.
8. Treat `beforeSend` as a final filter, not the only privacy control. Hook failures fail open to continued processing.

## 12. Troubleshooting

**No events arrive.** Confirm `createSDK()` completed, the API key is correct, any optional `baseUrl`/`SDK_BASE_URL` override is correct, remote routes are configured, the relevant feature and entitlement are enabled, and no killswitch is active. Inspect `getSDKHealth().circuitState`, queue drops, and SDK debug logs.

**`getConfig()` throws.** Initialization did not establish a validated remote configuration. Use `getSDKHealth()` before calling `getConfig()`.

**Spans are missing or disconnected.** Initialize before loading instrumented libraries; prefer `withSpan()` over `startSpan()` when child work needs an active parent. Ensure tracing and the relevant integration are enabled. Existing global OpenTelemetry setup is reused rather than replaced.

**Requests lack bodies/headers.** Privacy capture is backend-controlled. Enable the required `privacy.capture` fields remotely only after reviewing data exposure. Express must parse JSON before middleware for object-body capture.

**Optional APIs silently do nothing.** This is expected when entitlements are explicitly false or the associated feature/subsystem is disabled. Profiles and logs also require completed SDK initialization.

**Flush or shutdown returns before all sends succeed.** Flushes are bounded and best-effort; route circuit state, retries, queue overflow, process termination, and filesystem/network failures can leave residual or dropped telemetry. Inspect `ShutdownResult` and health counters.

**Duplicates appear.** Failed events and shutdown residuals can be replayed. A response lost after backend acceptance also causes retry. Deduplicate by stable `eventId`; the SDK does not guarantee exactly-once delivery.

**High overhead.** Reduce sampling, disable unneeded instrumentation and payload capture, lower metric cardinality, and monitor pending/transport queues. The pipeline schedules one `setImmediate` per accepted event, and JSON serialization still occurs in-process even though gzip itself uses asynchronous zlib.